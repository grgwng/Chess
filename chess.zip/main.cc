#include "game/Game.h"

int main() {
    Game game;
    game.runProgram();
}
