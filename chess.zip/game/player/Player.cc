#include "Player.h"

Player::Player(Colour colour): colour{colour} {}
